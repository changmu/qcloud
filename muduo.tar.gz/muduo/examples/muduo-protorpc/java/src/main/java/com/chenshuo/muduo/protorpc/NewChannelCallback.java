package com.chenshuo.muduo.protorpc;

public interface NewChannelCallback {

    public abstract void run(RpcChannel channel);
}
